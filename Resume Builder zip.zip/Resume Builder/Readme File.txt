Readme File...

1)open file
	Resume Builder -> Home_Page -> index.html

2)For user:
	i)   Sign in with email id, username and password
	ii)  Login with username and password
	iii) Fill details
	iv)  Choose template
	v)   Download pdf