// // import myLibrary from './https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.3.1/jspdf.umd.min.js'
// name
document.getElementById("fnamevalues").innerHTML=localStorage.getItem("fnamevalue");

// aboutyou
document.getElementById("aboutyouvalue").innerHTML=localStorage.getItem("about_you_value");

//city
document.getElementById("cityvalue").innerHTML=localStorage.getItem("cityvalue");

//country
document.getElementById("countryvalue").innerHTML=localStorage.getItem("countryvalue");

//email
document.getElementById("emailvalue").innerHTML=localStorage.getItem("emailvalue");

//mobilenumber
document.getElementById("phonevalue").innerHTML=localStorage.getItem("phonevalue");

//linkedIn
document.getElementById("linkedinvalue").innerHTML=localStorage.getItem("Linked_In");

//gitHub
document.getElementById("gitvalue").innerHTML=localStorage.getItem("Git_hub");

//shortinfovalue
document.getElementById("shortinfo").innerHTML=localStorage.getItem("shortinfovalue");


//Skill
//1
document.getElementById("skill1").innerHTML=localStorage.getItem("skill1value");

//2
document.getElementById("skill2").innerHTML=localStorage.getItem("skill2value");

//3
document.getElementById("skill3").innerHTML=localStorage.getItem("skill3value");

//4
document.getElementById("skill4").innerHTML=localStorage.getItem("skill4value");

//5
document.getElementById("skill5").innerHTML=localStorage.getItem("skill5value");

//6
document.getElementById("skill6").innerHTML=localStorage.getItem("skillvalue");


//compony 
document.getElementById("com1").innerHTML=localStorage.getItem("comvalue1");
document.getElementById("role1").innerHTML=localStorage.getItem("rolevalue1");
document.getElementById("jobdis1").innerHTML=localStorage.getItem("jobdisvalue1");
document.getElementById("jstarte1").innerHTML=localStorage.getItem("jsyearvalue1");
document.getElementById("jsende1").innerHTML=localStorage.getItem("jeyearvalue1");

document.getElementById("com2").innerHTML=localStorage.getItem("comvalue2");
document.getElementById("role2").innerHTML=localStorage.getItem("rolevalue2");
document.getElementById("jobdis2").innerHTML=localStorage.getItem("jobdisvalue2");
document.getElementById("jstarte2").innerHTML=localStorage.getItem("jsyearvalue2");
document.getElementById("jsende2").innerHTML=localStorage.getItem("jeyearvalue2");


document.getElementById("com3").innerHTML=localStorage.getItem("comvalue3");
document.getElementById("role3").innerHTML=localStorage.getItem("rolevalue3");
document.getElementById("jobdis3").innerHTML=localStorage.getItem("jobdisvalue3");
document.getElementById("jstarte3").innerHTML=localStorage.getItem("jsyearvalue3");
document.getElementById("jsende3").innerHTML=localStorage.getItem("jeyearvalue3");

//Education
document.getElementById("Coursename1").innerHTML=localStorage.getItem("cnvalue1");
document.getElementById("feildname1").innerHTML=localStorage.getItem("flvalue1");
document.getElementById("clgname1").innerHTML=localStorage.getItem("clgvalue1");
document.getElementById("statename1").innerHTML=localStorage.getItem("estatevalue1");
document.getElementById("estyear1").innerHTML=localStorage.getItem("estyearvalue1");
document.getElementById("eendyear1").innerHTML=localStorage.getItem("eendyearvalue1");
document.getElementById("cgpa1").innerHTML=localStorage.getItem("cgpavalue1");

document.getElementById("Coursename2").innerHTML=localStorage.getItem("cnvalue2");
document.getElementById("feildname2").innerHTML=localStorage.getItem("flvalue2");
document.getElementById("clgname2").innerHTML=localStorage.getItem("clgvalue2");
document.getElementById("statename2").innerHTML=localStorage.getItem("estatevalue2");
document.getElementById("estyear2").innerHTML=localStorage.getItem("estyearvalue2");
document.getElementById("eendyear2").innerHTML=localStorage.getItem("eendyearvalue2");
document.getElementById("cgpa2").innerHTML=localStorage.getItem("cgpavalue2");



// achievement
document.getElementById("ach1").innerHTML=localStorage.getItem("achvalue1");
document.getElementById("ach2").innerHTML=localStorage.getItem("achvalue2");
document.getElementById("ach3").innerHTML=localStorage.getItem("achvalue3");
document.getElementById("ach4").innerHTML=localStorage.getItem("achvalue4");
document.getElementById("ach5").innerHTML=localStorage.getItem("achvalue5");
document.getElementById("ach6").innerHTML=localStorage.getItem("achvalue6");


// // const re1 = document.getElementById("inner");

function getpdfnow(){
  
window.print();
}























