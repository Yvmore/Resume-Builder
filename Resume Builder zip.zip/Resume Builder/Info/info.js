//..........................logout.......................
document.getElementById("mainmenu").onclick=function(){
    document.location.href="/Home_Page/index.html";
}

// //............................................................Validation............................................................................................
let f_name=document.getElementById("f_name");
let city=document.getElementById("city");
let email=document.getElementById("email");
let phone=document.getElementById("phone");
let shortinfo=document.getElementById("shortinfo");
let comp_name=document.getElementById("company_0");
let title=document.getElementById("title_0");
let j_desc=document.getElementById("jdescription_0");
let scl=document.getElementById("school_0");
let degree=document.getElementById("degree_0");
let cgpa=document.getElementById("cgpa_0");
let year=document.getElementById("graduation_year_0");
let skill=document.getElementById("skill_name_0");
function validateForm(){
    
    if(f_name.value == "" || !(isNaN(f_name.value)) || city.value == "" || !(isNaN(city.value)) || email.value == "" || phone.value == "" || isNaN(phone.value) || phone.value.length<10 || phone.value.length>10 ){
        alert("Fill your Resume heading properly");
    }  
    else if( shortinfo.value == ""){
        alert("Provide your short information")
    }
    else if( comp_name.value == "" || title.value == ""  || j_desc.value == ""  ){
        alert("Provide your Experience")
    }
    else if(scl.value == "" || degree.value == "" || cgpa.value == "" || year.value == ""){
        alert("Provide your education")
    }
    else if(skill.value == ""){
        alert("Provide some skills")
    }
}

//.................................add experience..............................................
let flag1=1;
function addExperienceField(){

    let years1=["--SELECT START YEAR",2014,2015,2016,2017,2018,2019,2020,2021,2022,2023];
    let years2=["--SELECT END YEAR",2014,2015,2016,2017,2018,2019,2020,2021,2022,2023];

    let br=document.createElement('br');
    let hr=document.createElement('hr');

    let newNode1=document.createElement('input');
    newNode1.classList.add("form","margin");
    newNode1.setAttribute("id","company_" +flag1);
    newNode1.setAttribute("placeholder","Name of the Company");

    let newNode2=document.createElement('input');
    newNode2.classList.add("form","margin");
    newNode2.setAttribute("id","title_" +flag1);
    newNode2.setAttribute("placeholder","Job Title");

    let newNode4=document.createElement('select');
    newNode4.setAttribute("id","jstart_year_" +flag1);
    newNode4.classList.add("margin");
    for(let i=0;i<years1.length;i++){
        let option=document.createElement("option");
        option.value=years1[i];
        option.text=years1[i];
        newNode4.appendChild(option);
    }

    let newNode6=document.createElement('select');
    newNode6.setAttribute("id","jend_year_" +flag1);
    newNode6.classList.add("margin");
    for(let i=0;i<years2.length;i++){
        let option=document.createElement("option");
        option.value=years2[i];
        option.text=years2[i];
        newNode6.appendChild(option);
    }

    let newNode7=document.createElement('textarea');
    newNode7.classList.add("form");
    newNode7.setAttribute("id","jdescription_" +flag1);
    newNode7.setAttribute("placeholder","Job Description");
    newNode7.setAttribute("rows",3);

    let instruction=document.getElementById("instruction1");
    let addButton=document.getElementById("add1");

    instruction.insertBefore(br,addButton);
    instruction.insertBefore(hr,addButton);
    instruction.insertBefore(newNode1,addButton);
    instruction.insertBefore(newNode2,addButton);
    instruction.insertBefore(newNode7,addButton);
    instruction.insertBefore(br,addButton);
    instruction.insertBefore(newNode4,addButton);
    instruction.insertBefore(newNode6,addButton);
    instruction.insertBefore(br,addButton);

    flag1++;  
}

//....................................add education....................................................................
let flag2=1;
function addEducationField(){

    let br=document.createElement('br');
    let hr=document.createElement('hr');

    let months=["--SELECT STARTING YEAR--",2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025];
    let years=["--SELECT YEAR OF COMPLETION--",2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025];

    let newNode1=document.createElement('input');
    newNode1.classList.add("form");
    newNode1.setAttribute("id","school_" + flag2);
    newNode1.setAttribute("placeholder","Name of your Institute");
     
    let newNode3=document.createElement('input');
    newNode3.classList.add("form");
    newNode3.setAttribute("id","state_" + flag2);
    newNode3.setAttribute("placeholder","State");

    let newNode4=document.createElement('input');
    newNode4.classList.add("form");
    newNode4.setAttribute("id","degree_" + flag2);
    newNode4.setAttribute("placeholder","Degree");

    let newNode5=document.createElement('input');
    newNode5.classList.add("form");
    newNode5.setAttribute("id","field_" + flag2);
    newNode5.setAttribute("placeholder","Specialization if there");

    let newNode6=document.createElement('select');
    newNode6.classList.add("form");
    newNode6.setAttribute("id","start_year_" + flag2);
    for(let i=0;i<months.length;i++){
        let option=document.createElement("option");
        option.value=months[i];
        option.text=months[i];
        newNode6.appendChild(option);
    }

    let newNode7=document.createElement('select');
    newNode7.classList.add("form");
    newNode7.setAttribute("id","end_year_" + flag2);
    for(let i=0;i<years.length;i++){
        let option=document.createElement("option");
        option.value=years[i];
        option.text=years[i];
        newNode7.appendChild(option);
    }
    
    let newNode8=document.createElement('input');
    newNode8.classList.add("form");
    newNode8.setAttribute("id","cgpa_" + flag2);
    newNode8.setAttribute("placeholder","Grade");

    let instruction=document.getElementById("instruction2");
    let addButton=document.getElementById("add2");
    
    instruction.insertBefore(br,addButton);
    instruction.insertBefore(hr,addButton);
    instruction.insertBefore(newNode1,addButton);
    instruction.insertBefore(newNode3,addButton);
    instruction.insertBefore(newNode4,addButton);
    instruction.insertBefore(newNode5,addButton);
    instruction.insertBefore(newNode8,addButton);
    instruction.insertBefore(newNode6,addButton);
    instruction.insertBefore(newNode7,addButton);
    instruction.insertBefore(br,addButton);
    flag2++;
}

//........................................add skill...................................................................
let flag3=1;
function addSkillField(){

    let br=document.createElement('br');
    let newNode1=document.createElement('input');

    newNode1.classList.add("form");
    newNode1.setAttribute("placeholder","Enter Skill");
    newNode1.setAttribute("id","skill_name_" + flag3);

    let instruction=document.getElementById("instruction3");
    let addButton=document.getElementById("add4");

    instruction.insertBefore(br,addButton);
    instruction.insertBefore(newNode1,addButton);
    instruction.insertBefore(br,addButton);
    flag3++
}

//.........................................add acievements..........................................................
let flag4=1;
function addAchievements(){

    let br=document.createElement('br');
    let hr=document.createElement('hr');

    let newNode1=document.createElement('input');
    newNode1.classList.add("form");
    newNode1.setAttribute("id","achievement_" +flag4);
    newNode1.setAttribute("placeholder","Enter an Achievement");

    let instruction=document.getElementById("instruction4");
    let addButton=document.getElementById("add5");

    instruction.insertBefore(br,addButton);
    instruction.insertBefore(newNode1,addButton);
    instruction.insertBefore(br,addButton);

    flag4++;
}

// //............................passing values..............................................................

function saveData () {

    passValueHead();
    passValueExp();
    passValueEdu();
    passValueSkills();
    passValueAchieve();
}

// //......................................head and shortinfo..............................................

function passValueHead(){
    let full_name = document.getElementById("f_name").value;
    localStorage.setItem("fnamevalue",full_name);
    
    let countrydetails = document.getElementById("country").value;
    localStorage.setItem("countryvalue",countrydetails);

    let aboutyou = document.getElementById("about_you").value;
    localStorage.setItem("about_you_value",aboutyou);

    let citydetails = document.getElementById("city").value;
    localStorage.setItem("cityvalue",citydetails);

    let emaildetails = document.getElementById("email").value;
    localStorage.setItem("emailvalue",emaildetails);

    let phonedetails = document.getElementById("phone").value;
    localStorage.setItem("phonevalue",phonedetails);

    let link_in = document.getElementById("linked").value;
    localStorage.setItem("Linked_In",link_in);

    let git_Hub = document.getElementById("github").value;
    localStorage.setItem("Git_hub",git_Hub);

    //...............
    let shortinfodetails = document.getElementById("shortinfo").value;
    localStorage.setItem("shortinfovalue",shortinfodetails);
}
    

// //.....................................experience.................................................................

function passValueExp(){
    //1.............
    let comdetails1 = document.getElementById("company_0").value;
    localStorage.setItem("comvalue1",comdetails1);

    let roledetails1 = document.getElementById("title_0").value;
    localStorage.setItem("rolevalue1",roledetails1);

    let jobdisdetails1 = document.getElementById("jdescription_0").value;
    localStorage.setItem("jobdisvalue1",jobdisdetails1);

    let jsyear1 = document.getElementById("jstart_year_0").value;
    localStorage.setItem("jsyearvalue1",jsyear1);

    let jeyear1 = document.getElementById("jend_year_0").value;
    localStorage.setItem("jeyearvalue1",jeyear1);

    // 2....................
    let comdetails2 = document.getElementById("company_1").value;
    localStorage.setItem("comvalue2",comdetails2);

    let roledetails2 = document.getElementById("title_1").value;
    localStorage.setItem("rolevalue2",roledetails2);

    let jobdisdetails2 = document.getElementById("jdescription_1").value;
    localStorage.setItem("jobdisvalue2",jobdisdetails2);

    let jsyear2 = document.getElementById("jstart_year_1").value;
    localStorage.setItem("jsyearvalue2",jsyear2);

    let jeyear2 = document.getElementById("jend_year_1").value;
    localStorage.setItem("jeyearvalue2",jeyear2);

}
    
// //.............................................education................................................

function passValueEdu(){
    //1.....................
    let clgdetail1 = document.getElementById("school_0").value;
    localStorage.setItem("clgvalue1",clgdetail1);

    let estatedetail1 = document.getElementById("state_0").value;
    localStorage.setItem("estatevalue1",estatedetail1);

    let cndetail1 = document.getElementById("degree_0").value;
    localStorage.setItem("cnvalue1",cndetail1);

    let fldetail1 = document.getElementById("field_0").value;
    localStorage.setItem("flvalue1",fldetail1);

    let cgpadetail1 = document.getElementById("cgpa_0").value;
    localStorage.setItem("cgpavalue1",cgpadetail1);

    let estyeardetail1 = document.getElementById("start_year_0").value;
    localStorage.setItem("estyearvalue1",estyeardetail1);

    let eendyeardetail1 = document.getElementById("end_year_0").value;
    localStorage.setItem("eendyearvalue1",eendyeardetail1);

    //2............
    let clgdetail2 = document.getElementById("school_1").value;
    localStorage.setItem("clgvalue2",clgdetail2);

    let estatedetail2 = document.getElementById("state_1").value;
    localStorage.setItem("estatevalue2",estatedetail2);

    let cndetail2 = document.getElementById("degree_1").value;
    localStorage.setItem("cnvalue2",cndetail2);

    let fldetail2 = document.getElementById("field_1").value;
    localStorage.setItem("flvalue2",fldetail2);

    let cgpadetail2 = document.getElementById("cgpa_1").value;
    localStorage.setItem("cgpavalue2",cgpadetail2);

    let estyeardetail2 = document.getElementById("start_year_1").value;
    localStorage.setItem("estyearvalue2",estyeardetail2);

    let eendyeardetail2 = document.getElementById("end_year_1").value;
    localStorage.setItem("eendyearvalue2",eendyeardetail2);
    
}
    

// //......................................skills..........................................................................

function passValueSkills(){
    //1...................
    let skill1details = document.getElementById("skill_name_0").value;
    localStorage.setItem("skill1value",skill1details);

    let skill2details = document.getElementById("skill_name_1").value;
    localStorage.setItem("skill2value",skill2details);

    let skill3details = document.getElementById("skill_name_2").value;
    localStorage.setItem("skill3value",skill3details);
}
    
    
// //...............................achievements......................................................................

function passValueAchieve(){
    let achdetails1 = document.getElementById("achievement_0").value;
    localStorage.setItem("achvalue1",achdetails1);

    let achdetails2 = document.getElementById("achievement_1").value;
    localStorage.setItem("achvalue2",achdetails2);

    let achdetails3 = document.getElementById("achievement_2").value;
    localStorage.setItem("achvalue3",achdetails3);
}

    
    
